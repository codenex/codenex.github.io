function validate{
	var count=0;
	// if(document.getElementById("q11").checked)
		alert('sam');
		
}